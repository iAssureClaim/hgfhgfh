package com.cg.claim.dao;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import com.cg.claim.bean.Claim;
import com.cg.claim.bean.Policy;
import com.cg.claim.exception.ClaimException;

public interface IClaimDAO {

	public Claim viewClaim(long claimNumber) throws IOException, ClaimException, SQLException;

	public Policy viewPolicy(long policyNumber) throws IOException, ClaimException, SQLException;

	public List<Policy> viewAllPolicy(String userName) throws IOException, SQLException, ClaimException;

	public List<Claim> viewAllClaims(String userName) throws IOException, SQLException, ClaimException;

}
